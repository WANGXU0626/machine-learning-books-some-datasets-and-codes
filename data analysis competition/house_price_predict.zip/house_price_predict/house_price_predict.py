import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt 
import seaborn as sns 



train_data = pd.read_csv('Housingpricetrain.csv', index_col=0)
test_data = pd.read_csv('Housingpricetest.csv', index_col=0)
print(train_data.head())

"""
price = pd.DataFrame({'price':train_data['SalePrice'], 'log(price+1)':np.log1p(train_data['SalePrice'])})
plt.subplot(1,2,1)
sns.distplot(price['price'])
plt.title('Price')
plt.grid(1)
plt.subplot(1, 2, 2)
sns.distplot(price['log(price+1)'])
plt.title('log(price+1)')
plt.grid(1)
plt.show()
"""
print('\n---------------------------')
#学到了学到了 从上面的途中，我们可以发现price（即原来我们的目标）并不是平滑的。为了保证我们预测的准确性，在这里，我们将它们log1p化
#pop在去除该列的同时，将该列保存下来传给y_trian
y_train = np.log1p(train_data.pop('SalePrice'))
print(y_train.shape)          #目标标签
all_df = pd.concat([train_data, test_data], axis=0)   #等于0代表的是按行进行连接
print(all_df.shape)          #数据


"""
现在进行特征工程的处理


"""
print(all_df['MSSubClass'].dtype)
#将其转换成str型,好进行统计
all_df['MSSubClass'] = all_df['MSSubClass'].astype(str)   #转换数据类型
print(all_df['MSSubClass'].value_counts())

#我们可以发现SSubClass其实是一个类别标签，为了对其进行处理，要转换成one-hot编码
#pandas自带get_dummies方法，可以帮你一键做到One-Hot。
print(pd.get_dummies(all_df['MSSubClass'], prefix='MSSubClassGG').head())       # 16个类别

#现在我们对所有的category变量都改成one-hot编码
all_dummy_df = pd.get_dummies(all_df)
print(all_dummy_df.head())


#就算都是numerical变量，还是会出错，因为还存在又空缺值
print(all_dummy_df.isnull().sum().sort_values(ascending=False).head(10))

#一般情况下对缺失值的处理要考虑到实际情况，在这里我们仅仅使用平均值作为代替
mean_cols = all_dummy_df.mean()
#print(mean_cols.head(10))
all_dummy_df = all_dummy_df.fillna(mean_cols)
#print(all_dummy_df.isnull().sum().sort_values().head(5))

#现在需要标准化数据集了
"""
因为regression的分类器都比较傲娇，最好让数据都放在一个标准分布中，不要让数据间的差距过大

"""
#当然我们只要处理哪些类型是numerical的数据 对于one-hot的数据就不用进行处理了,从未处理前的数据集中筛选出这些特征
numerical_cols = all_df.columns[all_df.dtypes != 'object']
print(numerical_cols)



"""
#计算标准分布
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
scaler.fit_transform(all_dummy_df[numerical_cols])
print(all_dummy_df.head())

"""

numerical_cols_mean = all_dummy_df.loc[:, numerical_cols].mean()
numerical_cols_std = all_dummy_df.loc[:, numerical_cols].std()
all_dummy_df.loc[:, numerical_cols] = (all_dummy_df.loc[:, numerical_cols] - numerical_cols_mean) / numerical_cols_std
print(all_dummy_df)


"""
建立模型
将数据集划分

"""

dummy_train_df = all_dummy_df.loc[:len(train_data)]
dummy_test_df = all_dummy_df.loc[len(train_data)+1:]
print(dummy_train_df.shape)
print(dummy_test_df.shape)

#使用岭回归
from sklearn.linear_model import Ridge 
from sklearn.model_selection import cross_val_score

print('\n-----------------------------')
#将DF转换成Numpy.array 
x_train = dummy_train_df.values                    #.values()返回一个数组
x_test = dummy_test_df.values 
#print(x_train)

alphas = np.logspace(-3, 2, 50)
#print(alpha)
test_scores = []
for alpha in alphas:
    clf = Ridge(alpha)
    test_score = np.sqrt(-cross_val_score(clf, x_train, y_train, cv=5, scoring='neg_mean_squared_error'))
    test_scores.append(np.mean(test_score))

#print(test_scores)
plt.plot(alphas, test_scores)
plt.title('alpha and error')
plt.show()


"""
使用集成模型：随机森林

"""


from sklearn.ensemble import RandomForestRegressor 
"""
max_feature = [.1, .3, .5, .7, .9, .99]
test_scores = []
for max_feat in max_feature:
    clf = RandomForestRegressor(n_estimators=200,max_features=max_feat)
    test_score =np.sqrt(-cross_val_score(clf, x_train, y_train, cv=5, scoring='neg_mean_squared_error'))
    test_scores.append(np.mean(test_score))

plt.plot(max_feature, test_scores)
plt.show()
"""

#当然在这里我们要发挥集成模型的精髓，那么我们就分别取这两个模型的较优解

ridge = Ridge(0.15)
rf = RandomForestRegressor(n_estimators=200, max_features=0.3)

ridge.fit(x_train, y_train)
rf.fit(x_train, y_train)

#这个expm1就是因为之前我们的y是变换后的，现在要返回
predict_ridge = np.expm1(ridge.predict(x_test))
predict_rf = np.expm1(rf.predict(x_test))

y_final = (predict_rf + predict_ridge) / 2
#print(y_final.head())


submission_df = pd.DataFrame(data={'Id':test_data.index, 'SalePrice':y_final})
print(submission_df.head())