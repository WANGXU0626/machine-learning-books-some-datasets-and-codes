import matplotlib as mpl 
import matplotlib.pyplot as plt 
import numpy as np 
import pandas as pd 
import sklearn 
import os
import sys 
import time 
#import tensorflow as tf 
#from tensorflow import keras 
import seaborn as sns 

plt.rcParams['font.sans-serif'] = ['SimHei'] #用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False   #正常显示负号

#加载数据与数据预处理
print('\n---------------')
train_df = pd.read_csv('titanic_train.csv')
print(train_df.head())
print(train_df.describe())
eval_df = pd.read_csv('titanic_test.csv')
#y_train = train_df.pop('Survived')
#y_eval = veal_df.pop('Survived')
#print(y_train)
#print(train_df.head())

"""
train_df.set_index('PassengerId')
print(train_df.head())
females = (train_df['Sex'] == 'female').sum()
males = (train_df['Sex'] == 'male').sum()
print(females, males)
proportions = [males, females]
plt.pie(proportions, labels=['Males', 'Females'], colors=['blue', 'red'])
plt.axis('equal')
plt.title('Sex Proportion')
plt.show()

#绘制一个展示船票价格的直方图
df = train_df.Fare.sort_values(ascending=False)  #升序为false即为降序
print(df)
#create bins interval using numpy 
binsVal = np.arange(0, 600, 10)
plt.hist(df, bins=binsVal)
plt.xlabel('Fare')
plt.ylabel('Frequency')
plt.title('Fare Payed Histrogram')
plt.show()

"""

"""
#哪个性别的年龄的平均值更大
print(train_df.groupby('Sex').Age.mean())            #按照sex进行分组，查看每个分组中的平均年龄
#打印出不同性别的年龄的描述性统计信息
print(train_df.groupby('Sex').Age.describe())
#先对survived再对Fare进行排序
a = train_df.sort_values(['Survived', 'Fare'], ascending= False)
print(a)
#选取名字以字母A开头的数据
b = train_df[train_df.Name.str.startswith('A')]
print(b)
print('\n-------------------------------')

ts = pd.Series(np.random.randn(1000), index=pd.date_range('1/1/2000', periods=1000))
ts = ts.cumsum()
ts.plot()
plt.show()

"""

#处理空缺值
def null_table(train_df, eval_df):
    print('Training Data Frame')
    print(pd.isnull(train_df).sum())
    #print('\n')



#null_table(train_df, eval_df)
train_df.drop(['Cabin', 'Ticket'], axis = 1, inplace = True)        #inplace = True不加的话不会丢弃
#print(pd.isnull(train_df).sum())
print('\n----------------------')
eval_df.drop(['Cabin', 'Ticket'], axis = 1, inplace = True)
#print(pd.isnull(eval_df).sum())


#防止处理后不太好，先copy保存一份
copy_train = train_df.copy()
copy_train.dropna(inplace= True)
sns.distplot(copy_train['Age'])
plt.show()

#将NaN用均值中位数代替,解决所有的空缺值了
train_df['Age'].fillna(train_df['Age'].median(), inplace= True)
eval_df['Age'].fillna(eval_df['Age'].median(), inplace= True)
train_df['Embarked'].fillna('S', inplace= True)
eval_df['Fare'].fillna(eval_df['Fare'].median(), inplace=True)
print(pd.isnull(train_df).sum())
print(pd.isnull(eval_df).sum())
print(train_df.head())


"""
#plot and visualize data
sns.barplot(x='Sex', y='Survived', data=train_df)
plt.title(u'性别和存活情况')
plt.show()

total_survived_females = train_df[train_df['Sex'] == 'female']['Survived'].sum()         #1表示存活
print(total_survived_females)
total_survived_males = train_df[train_df['Sex'] == 'male']['Survived'].sum() 
print(total_survived_males)


#看看class扮演的角色
sns.barplot(x='Pclass', y='Survived', data=train_df)
plt.title('class和存活情况')
plt.show()


total_survived_class1 = train_df[train_df['Pclass'] == 1]['Survived'].sum()
total_survived_class2 = train_df[train_df['Pclass'] == 2]['Survived'].sum()
total_survived_class3 = train_df[train_df['Pclass'] == 3]['Survived'].sum()
print(total_survived_class1, total_survived_class2, total_survived_class3)


#联合分析
sns.barplot(x='Pclass', y='Survived', hue='Sex', data=train_df)
plt.ylabel('survival rate')
plt.title('联合性别和类别的存活情况')
plt.show()
"""

"""
现在看看年龄对最后是否存活的影响

"""

"""
survived_age = train_df[train_df['Survived'] == 1]['Age']
not_survived_age = train_df[train_df['Survived'] == 0]['Age']
plt.subplot(1, 2, 1)
plt.grid(True)
sns.distplot(survived_age, kde=False)
plt.title('Survived')
plt.ylabel('number')
plt.subplot(1,2,2)
plt.grid(True)
sns.distplot(not_survived_age, kde=False)
plt.title('not survived')
plt.show()

sns.stripplot(x='Survived', y='Age', data=train_df, jitter=True)
plt.show()

"""

"""
sns.pairplot(train_df)
plt.show()
"""

#print(train_df.head(10))
train_df.loc[train_df['Sex'] == 'male', 'Sex'] = 0
train_df.loc[train_df['Sex'] == 'female', 'Sex'] = 1   #必须指定是‘Sex'，不然就会针对整个数据进行处理
print(train_df)

train_df.loc[train_df['Embarked'] == 'S', 'Embarked'] = 0
train_df.loc[train_df['Embarked'] == 'C', 'Embarked'] = 1
train_df.loc[train_df['Embarked'] == 'Q', 'Embarked'] = 2
print(train_df)


print('\n-----------------------------------')
train_df['FamSize'] = train_df['SibSp'] + train_df['Parch'] + 1
eval_df['FamSize'] = eval_df['SibSp'] + eval_df['Parch'] + 1
train_df['IsAlone'] = train_df['FamSize'].apply(lambda x : 1 if x == 1 else 0)
eval_df['IsAlone'] = eval_df['FamSize'].apply(lambda x : 1 if x == 1 else 0)
print(train_df)


from sklearn.svm import SVC, LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier

from sklearn.metrics import make_scorer, accuracy_score 
from sklearn.model_selection import GridSearchCV 

features = ['Pclass', 'Sex', 'Age', 'Embarked', 'Fare', 'FamSize', 'IsAlone']
X_train = train_df[features]
y_train = train_df['Survived']
X_test = eval_df[features]

from sklearn.model_selection import train_test_split
X_train, X_valid, y_train, y_valid = train_test_split(X_train, y_train, test_size=0.2, random_state = 1)
svc_clf = SVC()
svc_clf.fit(X_train, y_train)
pred_svc = svc_clf.predict(X_valid)
acc_svc = accuracy_score(y_valid, pred_svc)
print('\n--------------------------')
print(acc_svc)

#LinearSVC Model
linsvc_clf = LinearSVC()
linsvc_clf.fit(X_train, y_train)
pred_linsvc = linsvc_clf.predict(X_valid)
acc_linsvc = accuracy_score(y_valid, pred_linsvc)
print(acc_linsvc)

rf_clf = RandomForestClassifier()
rf_clf.fit(X_train, y_train)
pred_rf = rf_clf.predict(X_valid)
acc_rf = accuracy_score(y_valid, pred_rf)
print(acc_rf)


